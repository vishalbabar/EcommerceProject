# SpringBootUnitTestTutorial

1. mvn clean
2. mvn test
3. mvn clean install 
4. Go to the target folder
5. java -jar demo-0.0.1-SNAPSHOT.jar
6. Verify your RESTful calls.

